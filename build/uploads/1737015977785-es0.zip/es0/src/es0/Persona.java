/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package es0;

/**
 *
 * @author silipoa
 */
public class Persona {
    //attributi 
    private String nome;
    private String cognome;
    
    //metodi 
    public Persona (String n, String c){
        nome = n;
        cognome = c;       
    }
        
}
